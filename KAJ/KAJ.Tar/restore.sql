--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "KAJ";
--
-- Name: KAJ; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "KAJ" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Indonesia.1252';


ALTER DATABASE "KAJ" OWNER TO postgres;

\connect "KAJ"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: kereta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kereta (
    id_kereta integer NOT NULL,
    nama_kereta character varying(25) NOT NULL,
    waktu_berangkat time(6) without time zone NOT NULL,
    waktu_tiba time(6) without time zone NOT NULL,
    harga integer NOT NULL
);


ALTER TABLE public.kereta OWNER TO postgres;

--
-- Name: kereta_id_kereta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kereta_id_kereta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kereta_id_kereta_seq OWNER TO postgres;

--
-- Name: kereta_id_kereta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kereta_id_kereta_seq OWNED BY public.kereta.id_kereta;


--
-- Name: pemesanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pemesanan (
    id_pemesanan integer NOT NULL,
    tanggal date NOT NULL,
    id_perjalanan integer NOT NULL,
    nomor_kursi character varying(10) NOT NULL,
    nomor_gerbong integer NOT NULL,
    id_penumpang integer NOT NULL
);


ALTER TABLE public.pemesanan OWNER TO postgres;

--
-- Name: pemesanan_id_pemesanan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pemesanan_id_pemesanan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pemesanan_id_pemesanan_seq OWNER TO postgres;

--
-- Name: pemesanan_id_pemesanan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pemesanan_id_pemesanan_seq OWNED BY public.pemesanan.id_pemesanan;


--
-- Name: pemesanan_id_penumpang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pemesanan_id_penumpang_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pemesanan_id_penumpang_seq OWNER TO postgres;

--
-- Name: pemesanan_id_penumpang_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pemesanan_id_penumpang_seq OWNED BY public.pemesanan.id_penumpang;


--
-- Name: pemesanan_id_perjalanan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pemesanan_id_perjalanan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pemesanan_id_perjalanan_seq OWNER TO postgres;

--
-- Name: pemesanan_id_perjalanan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pemesanan_id_perjalanan_seq OWNED BY public.pemesanan.id_perjalanan;


--
-- Name: penumpang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.penumpang (
    id_penumpang integer NOT NULL,
    nama_penumpang character varying(25) NOT NULL
);


ALTER TABLE public.penumpang OWNER TO postgres;

--
-- Name: penumpang_id_penumpang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.penumpang_id_penumpang_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.penumpang_id_penumpang_seq OWNER TO postgres;

--
-- Name: penumpang_id_penumpang_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.penumpang_id_penumpang_seq OWNED BY public.penumpang.id_penumpang;


--
-- Name: perjalanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.perjalanan (
    id_perjalanan integer NOT NULL,
    asal character varying(50) NOT NULL,
    tujuan character varying(50) NOT NULL,
    tanggal date NOT NULL,
    id_kereta integer NOT NULL
);


ALTER TABLE public.perjalanan OWNER TO postgres;

--
-- Name: perjalanan_id_kereta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.perjalanan_id_kereta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.perjalanan_id_kereta_seq OWNER TO postgres;

--
-- Name: perjalanan_id_kereta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.perjalanan_id_kereta_seq OWNED BY public.perjalanan.id_kereta;


--
-- Name: perjalanan_id_perjalanan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.perjalanan_id_perjalanan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.perjalanan_id_perjalanan_seq OWNER TO postgres;

--
-- Name: perjalanan_id_perjalanan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.perjalanan_id_perjalanan_seq OWNED BY public.perjalanan.id_perjalanan;


--
-- Name: transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaksi (
    id_transaksi integer NOT NULL,
    jumlah_transaksi integer NOT NULL,
    tanggal date NOT NULL,
    id_penumpang integer NOT NULL,
    keterangan character varying(25) NOT NULL
);


ALTER TABLE public.transaksi OWNER TO postgres;

--
-- Name: transaksi_id_penumpang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaksi_id_penumpang_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaksi_id_penumpang_seq OWNER TO postgres;

--
-- Name: transaksi_id_penumpang_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transaksi_id_penumpang_seq OWNED BY public.transaksi.id_penumpang;


--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaksi_id_transaksi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaksi_id_transaksi_seq OWNER TO postgres;

--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transaksi_id_transaksi_seq OWNED BY public.transaksi.id_transaksi;


--
-- Name: kereta id_kereta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kereta ALTER COLUMN id_kereta SET DEFAULT nextval('public.kereta_id_kereta_seq'::regclass);


--
-- Name: pemesanan id_pemesanan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pemesanan ALTER COLUMN id_pemesanan SET DEFAULT nextval('public.pemesanan_id_pemesanan_seq'::regclass);


--
-- Name: pemesanan id_perjalanan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pemesanan ALTER COLUMN id_perjalanan SET DEFAULT nextval('public.pemesanan_id_perjalanan_seq'::regclass);


--
-- Name: pemesanan id_penumpang; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pemesanan ALTER COLUMN id_penumpang SET DEFAULT nextval('public.pemesanan_id_penumpang_seq'::regclass);


--
-- Name: penumpang id_penumpang; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.penumpang ALTER COLUMN id_penumpang SET DEFAULT nextval('public.penumpang_id_penumpang_seq'::regclass);


--
-- Name: perjalanan id_perjalanan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perjalanan ALTER COLUMN id_perjalanan SET DEFAULT nextval('public.perjalanan_id_perjalanan_seq'::regclass);


--
-- Name: perjalanan id_kereta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perjalanan ALTER COLUMN id_kereta SET DEFAULT nextval('public.perjalanan_id_kereta_seq'::regclass);


--
-- Name: transaksi id_transaksi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi ALTER COLUMN id_transaksi SET DEFAULT nextval('public.transaksi_id_transaksi_seq'::regclass);


--
-- Name: transaksi id_penumpang; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi ALTER COLUMN id_penumpang SET DEFAULT nextval('public.transaksi_id_penumpang_seq'::regclass);


--
-- Data for Name: kereta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kereta (id_kereta, nama_kereta, waktu_berangkat, waktu_tiba, harga) FROM stdin;
\.
COPY public.kereta (id_kereta, nama_kereta, waktu_berangkat, waktu_tiba, harga) FROM '$$PATH$$/3347.dat';

--
-- Data for Name: pemesanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pemesanan (id_pemesanan, tanggal, id_perjalanan, nomor_kursi, nomor_gerbong, id_penumpang) FROM stdin;
\.
COPY public.pemesanan (id_pemesanan, tanggal, id_perjalanan, nomor_kursi, nomor_gerbong, id_penumpang) FROM '$$PATH$$/3351.dat';

--
-- Data for Name: penumpang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.penumpang (id_penumpang, nama_penumpang) FROM stdin;
\.
COPY public.penumpang (id_penumpang, nama_penumpang) FROM '$$PATH$$/3353.dat';

--
-- Data for Name: perjalanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.perjalanan (id_perjalanan, asal, tujuan, tanggal, id_kereta) FROM stdin;
\.
COPY public.perjalanan (id_perjalanan, asal, tujuan, tanggal, id_kereta) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaksi (id_transaksi, jumlah_transaksi, tanggal, id_penumpang, keterangan) FROM stdin;
\.
COPY public.transaksi (id_transaksi, jumlah_transaksi, tanggal, id_penumpang, keterangan) FROM '$$PATH$$/3359.dat';

--
-- Name: kereta_id_kereta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kereta_id_kereta_seq', 1, true);


--
-- Name: pemesanan_id_pemesanan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pemesanan_id_pemesanan_seq', 1, false);


--
-- Name: pemesanan_id_penumpang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pemesanan_id_penumpang_seq', 1, false);


--
-- Name: pemesanan_id_perjalanan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pemesanan_id_perjalanan_seq', 1, false);


--
-- Name: penumpang_id_penumpang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.penumpang_id_penumpang_seq', 1, false);


--
-- Name: perjalanan_id_kereta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.perjalanan_id_kereta_seq', 1, false);


--
-- Name: perjalanan_id_perjalanan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.perjalanan_id_perjalanan_seq', 1, false);


--
-- Name: transaksi_id_penumpang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaksi_id_penumpang_seq', 1, false);


--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaksi_id_transaksi_seq', 1, false);


--
-- Name: kereta kereta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kereta
    ADD CONSTRAINT kereta_pkey PRIMARY KEY (id_kereta);


--
-- Name: pemesanan pemesanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pemesanan
    ADD CONSTRAINT pemesanan_pkey PRIMARY KEY (id_pemesanan);


--
-- Name: penumpang penumpang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.penumpang
    ADD CONSTRAINT penumpang_pkey PRIMARY KEY (id_penumpang);


--
-- Name: perjalanan perjalanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.perjalanan
    ADD CONSTRAINT perjalanan_pkey PRIMARY KEY (id_perjalanan);


--
-- Name: transaksi transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi
    ADD CONSTRAINT transaksi_pkey PRIMARY KEY (id_transaksi);


--
-- PostgreSQL database dump complete
--

